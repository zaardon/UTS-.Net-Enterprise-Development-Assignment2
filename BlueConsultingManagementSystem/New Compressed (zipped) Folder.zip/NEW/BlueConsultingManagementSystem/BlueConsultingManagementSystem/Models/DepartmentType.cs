﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlueConsultingManagementSystem.Models
{
    public enum DepartmentType
    {
        HigherEducation,
        State,
        Logistics
    }
}
